create procedure       curDictList(rootId in number,nDepth in number,parentId in number) AS
    done number DEFAULT 0;
    DictNo number;

    CURSOR curDict
    IS SELECT id FROM t_sys_dict WHERE parent_id = rootId AND del_flag = 0;
    curDict1 curDict%rowtype;
BEGIN
    OPEN curDict;
    loop
    fetch curDict into curDict1;
    exit when curDict%notfound;
    if curDict%rowcount = 0 then
    begin
        done := 1;
    end;
    end if;
    end loop;
    close curDict;
    UPDATE tmp_dict_list SET IS_LEAF = 0 WHERE RID = parentId;
    commit;

    INSERT INTO tmp_dict_list VALUES (NULL, rootId, nDepth, 1);
    commit;
    OPEN curDict;
    FETCH curDict INTO DictNo;

    WHILE done = 0 loop
    curDictList (DictNo, nDepth + 1, rootId);
    FETCH curDict INTO DictNo;

    END loop;
    CLOSE curDict;
END;

/


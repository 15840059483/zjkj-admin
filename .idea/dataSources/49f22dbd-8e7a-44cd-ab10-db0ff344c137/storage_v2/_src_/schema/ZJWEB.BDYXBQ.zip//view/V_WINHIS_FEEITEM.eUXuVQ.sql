create view V_WINHIS_FEEITEM as
select a.card_no, --???,
       a.clinic_code, --?????,
       a.item_name, --????,
       a.specs, --??,
       a.use_name, --??,
       a.dose_once, --????,
       a.dose_unit, --??????,
       a.exec_dpnm,  --????,
       a.invoice_no --???
        from fin_opb_feedetail@zjwebhis a
        where a.drug_flag='1' and a.pay_flag='1'
/


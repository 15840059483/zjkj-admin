create trigger TR_T_SYS_WECHAT_ORDERINFO_WORK
    before insert
    on T_SYS_WECHAT_ORDERINFO
    for each row
BEGIN if :new.costname = '????'
    then :new.costtype:='4012';
    end IF;
    :new.HOSPITALNAME:='???????';
    END;
/


create package body       pack_returnInfo as
procedure queryDictList(rootId in number)
is

    str_sql varchar2(2000);
    num   number;

BEGIN
    select count(1) into num from user_tables where table_name = upper('tmp_Organization_list') ;
    if num > 0 then
        execute immediate 'drop table tmp_Organization_list' ;
    end if;
    str_sql:='CREATE TABLE tmp_Organization_list {
                SNO NUMBER primary key not null,
                RID NUMBER,
                DEPTH NUMBER,
                IS_LEAF NUMBER
                );';
    execute immediate str_sql;
    commit;

    DELETE FROM tmp_Organization_list;
    commit;
    curOrganizationList(rootId, 0, 0);
    SELECT A.SNO,A.RID,A.DEPTH,A.IS_LEAF,B.ID,B.ORGANIZATION_NAME,B.ORGANIZATION_TYPE,B.ORGANIZATION_KEY,B.PROVINCE,B.CITY,B.AREA,B.STREET,B.ORGANIZATION_ICON,
        B.ORGANIZATION_LEVEL,B.PARENT_ID,B.CREATE_TIME,B.UPDATE_TIME,B.OPERATOR,B.DESCRIPTION
        into info.SNO,info.RID,info.DEPTH,info.IS_LEAF,info.ID,info.ORGANIZATION_NAME,info.ORGANIZATION_TYPE,info.ORGANIZATION_KEY,info.PROVINCE,info.CITY,info.AREA,info.STREET,info.ORGANIZATION_ICON,
        info.ORGANIZATION_LEVEL,info.PARENT_ID,info.CREATE_TIME,info.UPDATE_TIME,info.OPERATOR,info.DESCRIPTION
        FROM tmp_Organization_list A, t_sys_organization B
        WHERE A.RID = B.ID AND B.DEL_FLAG = 0
        ORDER BY
        A.SNO;

END;
end pack_returnInfo;

/


create procedure       curOrganizationList(rootId in number,nDepth in number,parentId in number) as
done NUMBER DEFAULT 0;
OrganizationNo NUMBER;
BEGIN
    DECLARE CURSOR curOrganization IS SELECT id FROM t_sys_organization WHERE PARENT_ID = rootId AND DEL_FLAG = 0;
    curOrganization1 curOrganization%rowtype;
    BEGIN
      UPDATE tmp_Organization_list SET IS_LEAF = 0 WHERE RID = parentId;
      COMMIT;
      INSERT INTO tmp_Organization_list VALUES (NULL, rootId, nDepth, 1);
      COMMIT;
      BEGIN
        OPEN curOrganization;
        LOOP
            FETCH curOrganization INTO curOrganization1;
            EXIT WHEN curOrganization%NOTFOUND;
            if curOrganization%rowcount = 0 then
            begin
                done:=1;
            end;
            end if;
          END LOOP;

            WHILE done = 0 loop
            --curOrganizationList(OrganizationNo, nDepth + 1, rootId);
            FETCH curOrganization INTO OrganizationNo;
            END loop;
            commit;
            END curOrganizationList;

      END;
    END;

/


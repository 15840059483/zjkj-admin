create view V_WINLIS_RESULT as
select seqno,patientid,patientsex,patientage,patientageunit,patienttel,barcode,machineid,
sampleid,sampletime,testdate,CHECKDATE,itemid,itemname,rangeinfo,unit,resultflag,reportvalue,
sampletype,patienttype,patientname,hisitemid,hisitemname,doctorname,deptname,printseq
 from (
WITH abc AS
 (select t.hisitemidlist, t.execsqn,t.hisitemnamelist
    from LAS_GM_SAMPLEREG@WINLISLINK t
   where t.TESTDATE >= '20180301'
     and t.TESTDATE <= '20180508'
   order by t.accepttime)

select e.execsqn as  seqno,
       e.patientid as  patientid,
       e.patientsex as  patientsex,
       e.patientage||e.patientageunit as patientage,
       e.patientageunit as patientageunit,
       e.patienttel as patienttel,
       e.barcode as barcode,
       e.machineid as machineid,
       e.sampleid as sampleid,
       e.sampletime as sampletime,
       e.testdate as testdate,
       e.approvetime as CHECKDATE,
       d.germid as itemid,--??????
       d.germname as  itemname,--??????
       '' as rangeinfo,
       d.UNIT as unit,
       d.SENSITIVITY as resultflag,
       d.ANTINAME as reportvalue,
       e.sampletype as sampletype,
       e.patienttype as patienttype,
       e.patientname as patientname,
       (CASE
         WHEN (select count(1)
                 from LAS_GM_SAMPLEREG@WINLISLINK a
                where a.execsqn = e.execsqn) > 1 THEN
          (select hisitemidlist
             from abc
            where execsqn = e.execsqn
              and rownum = 1)
         ELSE
          e.hisitemidlist
       END) AS hisitemid, --??????
       (CASE
         WHEN (select count(1)
                 from LAS_GM_SAMPLEREG@WINLISLINK a
                where a.execsqn = e.execsqn) > 1 THEN
          (select hisitemnamelist
             from abc
            where execsqn = e.execsqn
              and rownum = 1)
         ELSE
          e.hisitemnamelist
       END) AS hisitemname,
       e.doctorname as doctorname,
       e.deptname as deptname,
       d. printseq as printseq
  FROM view_las_gm_mixresult@WINLISLINK D, LAS_GM_SAMPLEREG@WINLISLINK E
 WHERE D.TESTDATE = E.TESTDATE
   AND D.SAMPLEID = E.SAMPLEID
   AND D.MACHINEID = E.MACHINEID
   AND E.CONFIRMSTATE = '1'
   union all
    select s.execsqn as seqno,
       s.patientid as patientid,
       s.patientsex as patientsex,
       s.patientage||s.patientageunit as patientage,
       s.patientageunit as patientageunit,
       s.patienttel as patienttel,
       s.barcode as barcode,
       s.machineid as machineid,
       s.sampleid as sampleid,
       s.sampletime as sampletime,
       s.testdate as testdate,
       s.approvetime as CHECKDATE,
       t.itemid as itemid,
       t.itemname as itemname,
       t.rangeinfo as rangeinfo,
       t.unit as unit,
       decode(T.Resultflag,
              'Normal',
              '??',
              'Down',
              '?',
              'Up',
              '?',
              'LowLimit',
              '??',
              'HighLimit',
              '??',
              'Abnormal',
              '??',
              'Critical',
              '??',
              'NoFlag',
              '???',
              '???')as resultflag,
       t.reportvalue as reportvalue,
       t.sampletype as sampletype,
       s.patienttype as patienttype,
       s.patientname as patientname,
       s.hisitemidlist as hisitemid,
       s.hisitemnamelist as hisitemname,
       s.doctorname as  doctorname,
       s.deptname as deptname,
       t.printseq
  FROM LAS_RT_RESULT@WINLISLINK T, LAS_SAP_SAMPLEREG@WINLISLINK s
 WHERE s.TESTDATE = T.TESTDATE(+)
   AND s.MACHINEID = T.MACHINEID(+)
   AND s.SAMPLEID = T.SAMPLEID(+)
   and s.confirmstate = '1' ) tt
  order by  tt.printseq
/

